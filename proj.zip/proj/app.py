# from flask import Flask,request,render_template,jsonify
# from trace_path import trace_path
# app=Flask(__name__)

# @app.route('/')
# def main_route():
#     return render_template('index.html')

# @app.route('/trace_path',methods=["POST"])
# def trace_path_route():
#     data=request.form
#     source_ip=data.get('source')
#     destination_ip=data.get('destination')
#     if not source_ip or not destination_ip:
#         return jsonify({"error":"source and destination ips are required"}),401
    
#     paths=trace_path(source_ip,destination_ip)

#     return jsonify({'paths':paths})

# if __name__=='main':
#     app.run(debug=True)


from flask import Flask, request, render_template, jsonify
from trace_path import trace_path

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/trace_path', methods=['POST'])
def trace_path_route():
    data = request.form
    source_ip = data.get('source')
    destination_ip = data.get('destination')
    input_file = 'input.json'  # Replace with the path to your input file
    
    if not source_ip or not destination_ip:
        return jsonify({'error': 'Source and destination IPs are required'}), 400
    
    paths = trace_path(source_ip, destination_ip, input_file)
    
    return jsonify({'paths': paths})

if __name__ == '__main__':
    app.run(debug=True)
