MONGO_URI = "mongodb://localhost:27017/"
DATABASE_NAME = "network_db"
COLLECTION_NAME = "devices"
