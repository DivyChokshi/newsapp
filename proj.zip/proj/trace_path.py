import pymongo
import json
import networkx as nx
from config import MONGO_URI, DATABASE_NAME, COLLECTION_NAME

class NetworkTrace:
    def __init__(self):
        self.client = pymongo.MongoClient(MONGO_URI)
        self.db = self.client[DATABASE_NAME]
        self.collection = self.db[COLLECTION_NAME]
        self.graph = nx.Graph()
    
    def add_device_to_db(self, device_info):
        self.collection.update_one({"ip": device_info["ip"]}, {"$set": device_info}, upsert=True)
    
    def load_devices_from_file(self, filename):
        with open(filename, 'r') as file:
            devices = json.load(file)
            for device in devices:
                self.add_device_to_db(device)
    
    def build_graph_from_db(self):
        devices = self.collection.find()
        for device in devices:
            ip = device["ip"]
            lldp_neighbors = device["lldp_neighbors"]
            routing_table = device["routing_table"]
            self.graph.add_node(ip)
            for neighbor in lldp_neighbors:
                self.graph.add_edge(ip, neighbor)
            for route in routing_table:
                self.graph.add_edge(ip, route)
    
    def find_path(self, source_ip, destination_ip):
        return list(nx.all_shortest_paths(self.graph, source=source_ip, target=destination_ip))

def trace_path(source_ip, destination_ip, input_file):
    tracer = NetworkTrace()
    tracer.load_devices_from_file(input_file)
    tracer.build_graph_from_db()
    paths = tracer.find_path(source_ip, destination_ip)
    return paths
